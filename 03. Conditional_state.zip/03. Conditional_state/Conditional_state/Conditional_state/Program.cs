﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Conditional_state
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter Your Age : ");
            int age = Convert.ToInt32(Console.ReadLine());
            if (age >= 13)
            {
                if (age >= 18 && age < 60)
                {
                    Console.WriteLine("\nYou Are Adult.");
                }
                else if (age >= 13 && age < 18)
                {
                    Console.WriteLine("\nYou Are Teenage.");
                }
                else //(age >= 60)
                {
                    Console.WriteLine("\nYou Are Senior Citizen.");
                }
            }
            else
            {
                //if(age>0 && age<14)
                
                    Console.WriteLine("\nYou Are Child");
                }
              /*  else
                {
                    Console.WriteLine("\nI don't think you are living in world :)");
                }
            }*/
            Console.Read();
        }
    }
}
