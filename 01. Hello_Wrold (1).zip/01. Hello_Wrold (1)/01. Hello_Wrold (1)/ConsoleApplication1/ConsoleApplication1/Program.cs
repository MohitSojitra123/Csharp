﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program                    
    {
        static void Main(string[] args)
        {
            String nm;
            Console.WriteLine("Hello World!");  
            //Console.WriteLine("");
            Console.Write("\nEnter Your Name : ");
            nm = Console.ReadLine();
            Console.WriteLine("Your Name Is "+nm+".");
            Console.Read();
        }
    }
}
