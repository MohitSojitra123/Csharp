﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

// 1 2 3 6 18 108... n With Do..While

namespace Loop
{
    class Program
    {
        static void Main(string[] args)
        {
             Console.Write("Enter any number : ");
            int i = 1, old = 2, New = 3;
            int n = Convert.ToInt32(Console.ReadLine());
            do
            {
                if (i <= 3)
                {
                    Console.Write(i + " ");
                    i++;
                }
                else
                {
                    i = old * New;
                    if (i >= n)
                    {
                        break;
                    }
                    Console.Write(i + " ");
                    old = New;
                    New = i;
                }
            } while (i <= n);

// 1 2 3 6 18 108... n With For Loop

          /*  Console.Write("\n\nEnter any number : ");
            int  a = 2, b = 3;
            int num = Convert.ToInt32(Console.ReadLine());
            for (int j = 1; j <= num; j++)
            {
                if (j <= 3)
                {
                    Console.Write(j + " ");
                }
                else
                {
                    j = a * b;
                    if (j >= num)
                    {
                        break;
                    }
                    Console.Write(j + " ");
                    a = b;
                    b = j;
                }
            }

// 1 2 3 6 18 108... n With While Loop

            Console.Write("\n\nEnter any number : ");
            int present = 1, past = 2, future = 3;
            int number = Convert.ToInt32(Console.ReadLine());
            while (present <= number)
            {
                if (present <= 3)
                {
                    Console.Write(present + " ");
                    present++;
                }
                else
                {
                    present = past * future;
                    if (present > number)
                    {
                        break;
                    }
                    Console.Write(present + " ");
                    past = future;
                    future = present;
                }
            }*/
            Console.Read();
        }
    }
}
